package pm.academy.hw1;

public class HomeWorkClass {
    public int getPrimitiveFive() {
        int five = -10;
        return five;
    }

    public Integer getMinInteger() {
        return null;
    }

    public Integer getMaxInteger() {
        return null;
    }

    public Long getMinLong() {
        return null;
    }

    public Long getMaxLong() {
        return null;
    }

    public String writeToString() {
       return "";
    }

    public boolean checkForNegativeValue(int number) {
        return false;

    }

    public int getWeekday(Weekdays weekday) {
        if (weekday == null) {
            return -1;
        }
        return 0;
    }

    public int getFactorial(int val) {
        return 0;
    }

    public int findMaxValue(int a, int b) {
        return 0;
    }
}
